# NFTs_Upload_To_OpenSea

1. Download Python and Chrome browser 
2. pip install -r requirements.txt
5. python openseaupload.py (Run the script)
7. Press the "Open Chrome Browser" button
8. Set up your metamask wallet and login to Opensea using your wallet
9. Open the collection you want to upload to and copy the link
12. Click Start button